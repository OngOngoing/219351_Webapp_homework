#! /bin/sh

autoreconf -vif
